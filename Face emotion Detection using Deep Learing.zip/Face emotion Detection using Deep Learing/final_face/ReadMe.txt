open in Visual Studio Code
DOWNLOAD GIT BASH
open new terminal
select gitbash from plus button:
and enter command
using gitbash IDE 
open gitbash below the PowerShell at right bottom corner


you need to create a virtual environment 
beside the project folder


>> how to create a virtual environment

python -m venv environment-name(i've given 'venv' name for virtual environment)
> (source environment-name/Scripts/activate)         -source venv/Scripts/activate
> pip freeze
> pip install django

>> source venv/Scripts/activate
>>cd (file_name)final_face
>>cd fed
>>python manage.py runserver
#### fed refers to Face Emotion Detection



#the virtual environment and project folder should be in the same location

