from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about_page, name='about_page'),
    path('how-it-works/', views.how_it_works, name='how_it_works'),
    path('works/', views.how_it_works, name='works'),
    path('contact/', views.contact_us, name='contact_us'),
    path('contact/', views.contact_us, name='contact'),
    path('loginabout/', views.login_about_page, name='login_about_page'),
    path('loginworks/', views.login_how_it_works, name='login_how_it_works'),
    path('logincontact/', views.login_contact_us, name='login_contact_us'),
    path('login/', views.user_login, name='login'),
    path('signup/', views.user_signup, name='signup'),
    path('logout/', views.user_logout, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('video_stream/', views.video_stream, name='video_stream'),
    path('aboutus/', views.about_page, name='aboutus'),
    path('contact/success/', views.contact_success, name='contact_success'),
]
