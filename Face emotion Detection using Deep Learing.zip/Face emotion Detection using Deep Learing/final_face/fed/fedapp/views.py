from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout 
from .forms import UserCreationForm, LoginForm
from tensorflow.keras.layers import Conv2D
from tensorflow.keras.models import load_model
from django.http import StreamingHttpResponse 
import os,cv2
import numpy as np
from fed.settings import MEDIA_ROOT
from .forms import SignupForm
from django.core.mail import send_mail
from .forms import ContactForm
from django.shortcuts import render, redirect
from django.core.mail import send_mail
from .forms import ContactForm

def home(request):
    context={}
    return render(request, "fedapp/home.html", context)

def about_page(request):
    return render(request, 'fedapp/aboutus.html')

def login_about_page(request):
    return render(request, 'fedapp/loginabout.html')

def how_it_works(request):
    return render(request, 'fedapp/howitworks.html')

def contact_us(request):
    return render(request, 'fedapp/contact.html')

# New views for login versions of about, how it works, and contact us pages
def login_about_page(request):
    return render(request, 'fedapp/loginabout.html')

def login_how_it_works(request):
    return render(request, 'fedapp/loginworks.html')

def login_contact_us(request):
    return render(request, 'fedapp/logincontact.html')


def how_it_works(request):
    return render(request, 'fedapp/works.html')

def contact_us(request):
  if request.method == 'POST':
    form = ContactForm(request.POST)
    if form.is_valid():
      form.save()
      # Send email notification
      send_mail(
          subject='New Contact Form Submission',
          message=f'Name: {form.cleaned_data["name"]}\nEmail: {form.cleaned_data["email"]}\nMessage: {form.cleaned_data["message"]}',
          from_email='shanmukasreekar02@gmail.com',  # Updated Sender Email
          recipient_list=['recipient_email@example.com'],  # Update with your desired recipient email
          fail_silently=False,
      )
      return redirect('contact_success')  # Optional redirect to success page (if used)
  else:
    form = ContactForm()
  return render(request, 'contact.html', {'form': form})

def contact_success(request):
  return render(request, 'contact_success.html')

def home(request):
    context={}
    return render(request, "fedapp/home.html", context)

def about_page(request):
    return render(request, 'fedapp/aboutus.html')

def contact_us(request):
  return render(request, 'fedapp/contact.html')


def user_signup(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Log the user in automatically
            return redirect('login')  # Or another desired page
        else:
            # Handle invalid form data (optional)
            print(form.errors)  # This example just prints errors to the console
    else:
        form = SignupForm()
    return render(request, 'fedapp/signup.html', {'form': form})

# login page
def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)    
                return redirect('login')
    else:
        form = LoginForm()
    return render(request, 'fedapp/login.html', {'form': form})

# logout page
def user_logout(request):
    logout(request)
    return redirect('home')


def dashboard(request):
    return render(request, 'fedapp/dashboard.html')


def video_stream(request):
    model_name='face_detection.h5'
    model_path=os.path.join(MEDIA_ROOT, 'model', model_name)
    print("Model File Path:", model_path)
    model_emotion = load_model(model_path)

    model_emotion.summary()
    xml_file_name = 'haarcascade_frontalface_default.xml'
    xml_file_path = os.path.join(MEDIA_ROOT, 'haarcascades', xml_file_name)
    print("XML File Path:", xml_file_path)
    face_cascade=cv2.CascadeClassifier(xml_file_path)
    def stream():
        cap = cv2.VideoCapture(0)
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces=face_cascade.detectMultiScale(gray, scaleFactor=1.3, minNeighbors=5)
            for (x, y, w, h) in faces:
                face_image = frame[y:y+h, x:x+w]
                processed_face = cv2.resize(face_image, (48, 48))
                processed_face = np.expand_dims(processed_face, axis=0)
                processed_face = processed_face / 255.0
                emotion = model_emotion.predict(processed_face)
                label = np.argmax(emotion)
                emotions = ['anger', 'contempt', 'disgust', 'fear', 'happy', 'sadness', 'surprise']
                text = f"Emotion: {emotions[label]}"
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                print(emotion)
                print("Emorion: ",text)
                cv2.putText(frame, text, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (36,255,12), 2)
            _, buffer = cv2.imencode('.jpg', frame)


            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')

    return StreamingHttpResponse(stream(), content_type='multipart/x-mixed-replace; boundary=frame')